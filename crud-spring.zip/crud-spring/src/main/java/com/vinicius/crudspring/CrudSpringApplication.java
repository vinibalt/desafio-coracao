package com.vinicius.crudspring;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

import com.vinicius.model.Course;
import com.vinicius.repository.CourseRepository;

@SpringBootApplication
@ComponentScan
public class CrudSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudSpringApplication.class, args);
	}

	@Bean
	CommandLineRunner initDatabase(CourseRepository courseRepository){
		return args -> {
			courseRepository.deleteAll(); //limpa a base de dados

			Course c = new Course();
			c.setName("Angular com Spring");
			c.setCategory("Front-End");
			courseRepository.save(c);
		};
	}

}
