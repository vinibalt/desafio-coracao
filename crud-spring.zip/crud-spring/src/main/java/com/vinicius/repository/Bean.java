package com.vinicius.repository;

public @interface Bean {

}
