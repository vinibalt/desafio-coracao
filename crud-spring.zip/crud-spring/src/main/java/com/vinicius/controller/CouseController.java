package com.vinicius.controller;


import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.vinicius.model.Course;
import com.vinicius.repository.CourseRepository;

import lombok.AllArgsConstructor;


@RestController
@RequestMapping("/api/courses") //endpoint para obter info de cursos
@AllArgsConstructor // criar constructor automaticamente 
public class CouseController {
	
    private final CourseRepository courseRepository = null;
	
	

    @GetMapping //Servlet DoGet
    public List<Course> list(){
        return courseRepository.findAll();
    }

}
